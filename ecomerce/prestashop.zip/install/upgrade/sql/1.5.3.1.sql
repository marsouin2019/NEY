SET NAMES 'utf8';

/* PHP:p1531_redirect_type(); */;

ALTER IGNORE TABLE `PREFIX_cart` CHANGE `delivery_option` `delivery_option` TEXT NOT NULL;
